package com.bignerdranch.android.goldpoint;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Adapter;
import android.widget.ListAdapter;
import android.widget.ListView;

/**
 * Created by asus on 2017/9/24.
 */

public class PlayerScoreActivity extends AppCompatActivity {
    private ListView mListView;
    private static int[] mScore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.player_score_activity);
        mListView = (ListView)findViewById(R.id.playerScore_listView);
        Adapter adapter = new PlayerScoreAdapter(this,mScore);
        mListView.setAdapter((ListAdapter) adapter);
    }
    public static Intent newIntent(Context packContext,int[] score){
        Intent i = new Intent(packContext,PlayerScoreActivity.class);
        mScore = score;
        return i;
    }
}
