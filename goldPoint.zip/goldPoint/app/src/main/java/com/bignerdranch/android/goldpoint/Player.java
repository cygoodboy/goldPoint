package com.bignerdranch.android.goldpoint;

/**
 * Created by asus on 2017/9/24.
 */

public class Player {
    String mId;
    String mNumber="0";
    public Player(String id,String number){
        mId = id;
        mNumber = number;
    }
    public String getId() {
        return mId;
    }

    public void setId(String id) {
        mId = id;
    }

    public String getNumber() {
        return mNumber;
    }

    public void setNumber(String number) {
        mNumber = number;
    }


}
